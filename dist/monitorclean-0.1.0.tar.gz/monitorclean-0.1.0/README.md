# MonitorClean
Basit açıklama: MonitorClean QT uygulaması.
